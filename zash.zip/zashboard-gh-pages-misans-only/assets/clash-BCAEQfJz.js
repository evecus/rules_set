import{aR as s,aT as t,aU as o}from"./index-AxUvGIn1.js";const n=async()=>{s.value=(await t()).data},c=async a=>{await o(a),n()};export{n as fetchConfigs,c as updateConfigs};
