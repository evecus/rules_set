import{aV as e,aW as a}from"./index-CAI38SYq.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
