import{aV as e,aW as a}from"./index-AxUvGIn1.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
