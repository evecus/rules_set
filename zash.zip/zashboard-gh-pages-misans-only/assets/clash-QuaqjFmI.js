import{aP as s,aR as t,aS as o}from"./index-CKAHG7r4.js";const n=async()=>{s.value=(await t()).data},c=async a=>{await o(a),n()};export{n as fetchConfigs,c as updateConfigs};
