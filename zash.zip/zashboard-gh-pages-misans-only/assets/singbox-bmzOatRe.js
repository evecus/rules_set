import{aT as e,aU as a}from"./index-CKAHG7r4.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
