import{aT as e,aU as a}from"./index-BE7oWll_.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
